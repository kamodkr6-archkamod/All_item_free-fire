import sys
import subprocess
import os
import time
import json
import binascii
import asyncio
import re
import aiofiles
import traceback

# ─── Install requirements ──────────────────────────────────────
def install_requirements():
    GREEN = "\033[1;32m"; YELLOW = "\033[1;33m"; CYAN = "\033[1;36m"; R = "\033[0m"
    print(f"{CYAN}Checking requirements...{R}")
    for package in ['aiohttp', 'pycryptodome', 'protobuf', 'aiofiles', 'requests']:
        try:
            __import__(package)
        except ImportError:
            print(f"{YELLOW}Installing {package}...{R}")
            subprocess.check_call([sys.executable, '-m', 'pip', 'install', package, '--quiet'])
    print(f"{GREEN}All requirements ready.{R}\n")

install_requirements()

import aiohttp
import requests
import uuid as _uuid
import random as _random
import base64 as _b64
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
import zlib

# ─── Colors ────────────────────────────────────────────────────
R       = "\033[0m"
BOLD    = "\033[1m"
RED     = "\033[1;31m"
GREEN   = "\033[1;32m"
YELLOW  = "\033[1;33m"
BLUE    = "\033[1;34m"
MAGENTA = "\033[1;35m"
CYAN    = "\033[1;36m"
WHITE   = "\033[1;37m"
GOLD    = "\033[1;33m"
BG_G    = "\033[1;37;42m"
BG_Y    = "\033[1;37;43m"

BANNER = f"""
{MAGENTA}╔══════════════════════════════════════════════════════╗
║{GOLD}            🔥  NARUTO BUNDLES SPINNER  🔥             {MAGENTA}║
║{CYAN}              Local JWT · Auto Retry                  {MAGENTA}║
╚══════════════════════════════════════════════════════╝{R}
"""

# ─── Config ────────────────────────────────────────────────────
DEBUG = False
#sasuke 
#NARUTO_PAYLOAD = "4B7E2956BCAF3DACD31A7B9E554C4246"
#first
#NARUTO_PAYLOAD = "B31B32FB8303719D61FC461DC26135E4"
#naruto
#NARUTO_PAYLOAD = "D120B9DAAC2C87872B8C115DFD74A832"
#nine tail
NARUTO_PAYLOAD = "7F8C67F6720CF39448AF9F690D90E1F1"

SERVER_URL  = "https://client.ind.freefiremobile.com"
LOGIN_RETRY = 3
SPIN_RETRY  = 3

SPECIAL_FILE = "naruto_items.json"
RARE_ACCOUNT_FILE = "rare_accounts.json"
SUMMARY_FILE = "naruto_summary.txt"
LOG_FILE = "naruto_log.txt"

NARUTO_DB = {
     710047022: ("NARUTO BUNDLE",         "VERY_RARE"),
    909047015: ("RASENGAN EMOTE",        "RARE"),
    907104746: ("HOKAGE ROCK GLOW WALL", "RARE"),
    904047008: ("HOKAGE GLOW WALL",      "NORMAL"),
    903047008: ("RASENGAN SKIN",         "NORMAL"),

    # ── NARUTO SKYWIN (event 2) ──
    911004701: ("NARUTO SKYWIN",         "VERY_RARE"),
    907104744: ("M4A1 - NARUTO THEME",   "RARE"),
    211047048: ("OBITO MASK",            "RARE"),

    # ── NARUTO FIST (event 3) ──
    907104745: ("FIST",                  "VERY_RARE"),

    # ── SASUKE BUNDLE (event 4) ──
    710047023: ("SASUKE BUNDLE",         "VERY_RARE"),
    907104743: ("KATANA",                "RARE"),
    907104742: ("KATANA",                "RARE"),
    907104748: ("GROZA",                 "RARE"),
    
    #nine tail emote
    912047002 : (" the Nine Tails ",        " very_rare"),
   500000008.:  ("Enhance Hammer ",       "not rare" )
}

IGNORE_IDS = {820981015, 500000003, 500000004, 500000005, 500000008}

# ─── AES / JWT constants ───────────────────────────────────────
AES_KEY = b'Yg&tc%DEuh6%Zc^8'
AES_IV  = b'6oyZDr22E3ychjM%'

DANGER_AES_KEY = _b64.b64decode('WWcmdGMlREV1aDYlWmNeOA==')
DANGER_AES_IV  = _b64.b64decode('Nm95WkRyMjJFM3ljaGpNJQ==')

OAUTH_URL     = "https://ffmconnect.live.gop.garenanow.com/oauth/guest/token/grant"
LOGIN_SERVER  = "https://loginbp.ggpolarbear.com"
CLIENT_SECRET = "2ee44819e9b4598845141067b281621874d0d5d7af9d8f7e00c1e54715b7d1e3"

CLIENT_VERSION   = "1.126.6"
CLIENT_USING_VER = "7428b253defc164018c604a1ebbfebdf"
RELEASE_VERSION  = "OB55"

LOG_BUF = []
JSON_LOCK = asyncio.Lock()

try:
    import DaNgErProTo_pb2 as DP
    PROTO_OK = True
except Exception as e:
    PROTO_OK = False
    print(f"{RED}DaNgErProTo_pb2 not found — cannot generate JWT.{R}")
    sys.exit(1)

try:
    import output_pb2 as OP
    OUT_OK = True
except Exception:
    OUT_OK = False

# ═══════════════════════════════════════════════════════════════
def log(msg):
    ts = time.strftime("[%H:%M:%S]")
    line = f"{ts} {msg}"
    print(line, flush=True)
    LOG_BUF.append(re.sub(r'\033\[[0-9;]*m', '', line))

def dbg(msg):
    if DEBUG:
        print(f"{MAGENTA}[debug]{R} {msg}", flush=True)

# ═══════════════════════════════════════════════════════════════
# JWT GENERATION
# ═══════════════════════════════════════════════════════════════
def _encrypt_jwt_req(pt: bytes) -> bytes:
    c = AES.new(DANGER_AES_KEY, AES.MODE_CBC, DANGER_AES_IV)
    pl = 16 - (len(pt) % 16) or 16
    return c.encrypt(pt + bytes([pl]) * pl)

def _set(obj, name, value):
    if not hasattr(obj, name):
        return
    try:
        setattr(obj, name, value)
    except Exception:
        pass

def _build_major_login(access_token, open_id):
    req = DP.MajorLoginReq()
    for k, v in [
        ("event_time", time.strftime("%Y-%m-%d %H:%M:%S")),
        ("game_name", "free fire"), ("platform_id", 2),
        ("client_version", CLIENT_VERSION), ("client_version_code", "2024010012"),
        ("system_software", "Android OS 11 / API-30 (RQ3A.210805.001)"),
        ("system_hardware", "Handheld"), ("device_type", "Handheld"),
        ("telecom_operator", "Verizon"), ("network_operator_a", "Verizon"),
        ("network_type", "WIFI"), ("network_type_a", "WIFI"),
        ("screen_width", 1080), ("screen_height", 2400), ("screen_dpi", "440"),
        ("processor_details", "ARMv8"), ("cpu_type", 2), ("cpu_architecture", "64"),
        ("memory", 6144), ("gpu_renderer", "Adreno (TM) 650"),
        ("gpu_version", "OpenGL ES 3.2 V@1.50"), ("graphics_api", "OpenGLES3"),
        ("unique_device_id", f"Google|{_uuid.uuid4()}"),
        ("client_ip", "0.0.0.0"), ("language", "en"),
        ("open_id", open_id), ("open_id_type", "4"), ("login_open_id_type", 4),
        ("access_token", access_token), ("login_by", 3), ("platform_sdk_id", 2),
        ("origin_platform_type", "4"), ("primary_platform_type", "4"), ("region", "IND"),
        ("external_storage_total", 128512),
        ("external_storage_available", _random.randint(38000, 52000)),
        ("internal_storage_total", 110731),
        ("internal_storage_available", _random.randint(18000, 32000)),
        ("game_disk_storage_total", 26628),
        ("game_disk_storage_available", _random.randint(18000, 25000)),
        ("external_sdcard_total_storage", 119234),
        ("external_sdcard_avail_storage", _random.randint(25000, 60000)),
        ("library_path", "/data/app/~~random/base.apk"),
        ("library_token", "hash|base.apk"),
        ("client_using_version", CLIENT_USING_VER),
        ("supported_astc_bitset", 16383),
        ("analytics_detail", b"FwQVTgUPX1UaUllDDwcWCRBpWAUOUgsvA1snWlBaO1kFYg=="),
        ("loading_time", _random.randint(9000, 18000)),
        ("release_channel", "android"), ("channel_type", 3),
        ("reg_avatar", 1), ("if_push", 1), ("is_vpn", 0),
        ("android_engine_init_flag", 110009),
    ]:
        _set(req, k, v)
    if hasattr(req, "memory_available"):
        try:
            req.memory_available.version = 55
            req.memory_available.hidden_value = 81
        except Exception:
            pass
    return req

def _parse_login_res(raw):
    for off in range(0, min(200, max(0, len(raw) - 16))):
        try:
            r = DP.MajorLoginRes()
            r.ParseFromString(raw[off:])
            t = getattr(r, "token", None)
            if t and isinstance(t, str) and len(t) > 50:
                return t
        except Exception:
            continue
    return None

def generate_jwt(uid: str, password: str, max_attempts: int = 6):
    """Returns (token, status): 'ok' | 'rate' | 'fail'."""
    for attempt in range(max_attempts):
        try:
            oauth = requests.post(
                OAUTH_URL,
                data=(f"uid={uid}&password={password}"
                      "&response_type=token&client_type=2"
                      f"&client_secret={CLIENT_SECRET}&client_id=100067"),
                headers={
                    "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 9; SM-G975F Build/PI)",
                    "Content-Type": "application/x-www-form-urlencoded",
                },
                timeout=15,
            )

            if oauth.status_code == 429:
                return None, "rate"
            if oauth.status_code != 200:
                time.sleep(1)
                continue

            try:
                od = oauth.json()
            except Exception:
                return None, "fail"

            access_token = od.get("access_token")
            open_id = od.get("open_id")
            if not access_token or not open_id:
                time.sleep(1)
                continue

            req = _build_major_login(access_token, open_id)
            body = req.SerializeToString()
            enc = _encrypt_jwt_req(body)

            ml = requests.post(
                f"{LOGIN_SERVER}/MajorLogin",
                headers={
                    'User-Agent': "UnityPlayer/2018.4.12f1 (UnityWebRequest/1.0, libcurl/8.5.0-DEV)",
                    'Accept': "*/*", 'Accept-Encoding': "deflate, gzip",
                    'X-GA-SV': str(int(time.time())), 'X-GA': "v1 1",
                    'ReleaseVersion': RELEASE_VERSION,
                    'Content-Type': "application/x-www-form-urlencoded",
                    'X-Unity-Version': "2018.4.12f1",
                    'Content-Length': str(len(enc)),
                },
                data=enc,
                timeout=20,
            )

            if ml.status_code == 429:
                return None, "rate"
            if ml.status_code != 200:
                time.sleep(1)
                continue

            raw = ml.content
            cands = [raw]
            if raw[:2] == b'\x1f\x8b':
                try:
                    import gzip as _gz
                    cands.insert(0, _gz.decompress(raw))
                except Exception:
                    pass
            try:
                cands.append(zlib.decompress(raw))
            except Exception:
                pass
            try:
                cands.append(zlib.decompress(raw, -zlib.MAX_WBITS))
            except Exception:
                pass

            for c in cands:
                tok = _parse_login_res(c)
                if tok:
                    return tok, "ok"

            time.sleep(1)
        except requests.exceptions.Timeout:
            time.sleep(2)
        except Exception:
            time.sleep(1)

    return None, "fail"

# ═══════════════════════════════════════════════════════════════
# GACHA PARSING
# ═══════════════════════════════════════════════════════════════
def parse_items(data: bytes):
    items = []
    try:
        if data.startswith(b'\x1f\x8b'):
            data = zlib.decompress(data, 16 + zlib.MAX_WBITS)
    except Exception:
        pass

    if OUT_OK:
        try:
            r = OP.Garena_420()
            r.ParseFromString(data)
            for num in re.findall(r'\b(\d{9})\b', str(r)):
                iid = int(num)
                if 100000000 <= iid <= 999999999 and not any(x['id'] == iid for x in items):
                    items.append({'id': iid})
        except Exception:
            pass

    if not items:
        try:
            for num in re.findall(r'\d{9}', data.decode('utf-8', errors='ignore')):
                iid = int(num)
                if 100000000 <= iid <= 999999999 and not any(x['id'] == iid for x in items):
                    items.append({'id': iid})
        except Exception:
            pass

    if not items:
        try:
            i = 0
            while i < len(data):
                v = 0; s = 0
                while i < len(data):
                    b = data[i]; i += 1
                    v |= (b & 0x7F) << s
                    if not (b & 0x80):
                        break
                    s += 7
                if 100000000 <= v <= 999999999 and not any(x['id'] == v for x in items):
                    items.append({'id': v})
        except Exception:
            pass

    return items

# ═══════════════════════════════════════════════════════════════
# HTTP SPIN
# ═══════════════════════════════════════════════════════════════
async def spin(session, token: str, payload: bytes, retries: int = 3):
    url = f"{SERVER_URL}/PurchaseGacha"
    headers = {
        'User-Agent': "UnityPlayer/2018.4.12f1 (UnityWebRequest/1.0, libcurl/8.5.0-DEV)",
        'Accept': "*/*", 'Accept-Encoding': "gzip, deflate",
        'Authorization': f"Bearer {token}", 'X-GA': "v1 1",
        'X-GA-SV': str(int(time.time())), 'ReleaseVersion': RELEASE_VERSION,
        'Content-Type': "application/x-www-form-urlencoded",
        'X-Unity-Version': "2018.4.12f1",
    }
    for attempt in range(retries):
        try:
            async with session.post(url, headers=headers, data=payload, ssl=False,
                                    timeout=aiohttp.ClientTimeout(total=20)) as r:
                body = await r.read()
                if r.status == 200:
                    return 200, body
                if r.status in (401, 403):
                    return r.status, body
        except Exception:
            pass
        await asyncio.sleep(0.3)
    return 0, b""

# ═══════════════════════════════════════════════════════════════
# SAVE
# ═══════════════════════════════════════════════════════════════
async def save_hit(entry):
    async with JSON_LOCK:
        for _ in range(3):
            try:
                data = []
                if os.path.exists(SPECIAL_FILE):
                    async with aiofiles.open(SPECIAL_FILE, 'r', encoding='utf-8') as f:
                        c = await f.read()
                        data = json.loads(c) if c else []
                data.append(entry)
                async with aiofiles.open(SPECIAL_FILE, 'w', encoding='utf-8') as f:
                    await f.write(json.dumps(data, indent=2))
                return
            except Exception:
                await asyncio.sleep(0.15)

# ═══════════════════════════════════════════════════════════════
# PROCESS ONE ACCOUNT
# ═══════════════════════════════════════════════════════════════
async def process(semaphore, session, acc, idx, total, payload):
    async with semaphore:
        uid = str(acc.get("uid", "?"))
        pwd = str(acc.get("password", "?"))

        log(f"{GOLD}[{idx}/{total}]{R} {CYAN}{uid}{R}")

        # ── JWT ──
        token, status = await asyncio.to_thread(generate_jwt, uid, pwd)

        if status == "rate":
            log(f"    {YELLOW}Rate limited → pausing 30s{R}")
            await asyncio.sleep(30)
            token, status = await asyncio.to_thread(generate_jwt, uid, pwd)

        if not token:
            log(f"    {RED}✗ Token failed{R}")
            return

        # ── Spin ──
        code, body = await spin(session, token, payload)

        if code != 200 or not body:
            log(f"    {RED}📦 Spin HTTP {code}{R}")
            return

        items = parse_items(body)

        # ── Filter ──
        found = []

        for it in items:
            iid = it["id"]

            if iid in IGNORE_IDS:
                continue

            found.append(iid)

        # ── No item ──
        if not found:
            log(f"    {WHITE}📦 No item{R}")
            return

        # ── Report each item ──
        for iid in found:

            if iid in NARUTO_DB:
                item_name, rarity = NARUTO_DB[iid]

                entry = {
                    "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
                    "uid": uid,
                    "password": pwd,
                    "item_id": iid,
                    "item_name": item_name,
                    "rarity": rarity
                }

                # Normal Naruto item
                await save_hit(entry)

                # ── Rare account ──
                if rarity.strip().upper() in ("RARE", "VERY_RARE"):
                    await save_rare_account(entry)

                    log(
                        f"    {BG_G} 💥 RARE ACCOUNT | "
                        f"{item_name} [{rarity}] | ID: {iid} {R}"
                    )
                else:
                    log(
                        f"    📦 {item_name} [{rarity}] | ID: {iid}"
                    )

            else:
                # Unknown item
                entry = {
                    "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
                    "uid": uid,
                    "password": pwd,
                    "item_id": iid,
                    "item_name": "Unknown"
                }

                await save_hit(entry)

                log(f"    📦 🗿 Unknown (ID: {iid})")


# ═══════════════════════════════════════════════════════════════
# SAVE RARE ACCOUNT
# ═══════════════════════════════════════════════════════════════
async def save_rare_account(entry):
    async with JSON_LOCK:
        for _ in range(3):
            try:
                data = []

                if os.path.exists(RARE_ACCOUNT_FILE):
                    async with aiofiles.open(
                        RARE_ACCOUNT_FILE,
                        "r",
                        encoding="utf-8"
                    ) as f:
                        content = await f.read()

                        if content.strip():
                            data = json.loads(content)

                # Same UID + same item duplicate nahi hoga
                duplicate = any(
                    str(x.get("uid")) == str(entry.get("uid"))
                    and int(x.get("item_id", 0))
                    == int(entry.get("item_id", 0))
                    for x in data
                )

                if not duplicate:
                    data.append(entry)

                    async with aiofiles.open(
                        RARE_ACCOUNT_FILE,
                        "w",
                        encoding="utf-8"
                    ) as f:
                        await f.write(
                            json.dumps(
                                data,
                                indent=2,
                                ensure_ascii=False
                            )
                        )

                return

            except Exception:
                await asyncio.sleep(0.15)          

# ═══════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════
async def main():
    os.system('cls' if os.name == 'nt' else 'clear')
    print(BANNER)

    # ── Accounts file ──
    while True:
        path = input(f"{CYAN}Accounts file path:{R} ").strip().strip('"').strip("'")
        if os.path.exists(path):
            break
        print(f"{RED}File not found, try again.{R}")

    try:
        with open(path, 'r', encoding='utf-8') as f:
            accounts = json.load(f)
        print(f"{GREEN}Loaded {len(accounts)} accounts.{R}\n")
    except Exception as e:
        print(f"{RED}Invalid JSON: {e}{R}")
        return

    # ── Threads ──
    try:
        raw = input(f"{CYAN}Threads (1-20, default 3):{R} ").strip()
        threads = int(raw) if raw else 3
        threads = max(1, min(20, threads))
    except Exception:
        threads = 3
    print(f"{GREEN}Using {threads} thread(s).{R}\n")

    payload = binascii.unhexlify(NARUTO_PAYLOAD)
    log(f"{CYAN}Payload:{R} {payload.hex().upper()}")
    log(f"{CYAN}Server:{R} {SERVER_URL}\n")

    sem = asyncio.Semaphore(threads)
    start = time.time()

    async with aiohttp.ClientSession() as session:
        tasks = [
            asyncio.create_task(process(sem, session, acc, i + 1, len(accounts), payload))
            for i, acc in enumerate(accounts)
        ]
        await asyncio.gather(*tasks, return_exceptions=True)

    elapsed = time.time() - start

    # ── Summary ──
    hits = 0
    if os.path.exists(SPECIAL_FILE):
        try:
            with open(SPECIAL_FILE) as f:
                hits = len(json.load(f))
        except Exception:
            pass

    print(f"\n{MAGENTA}═════════════════════════════════════════{R}")
    print(f"{BOLD}{WHITE}              DONE                       {R}")
    print(f"{MAGENTA}═════════════════════════════════════════{R}")
    print(f"{GREEN}Accounts processed : {len(accounts)}{R}")
    print(f"{GREEN}Items found        : {hits}{R}")
    print(f"{GREEN}Time               : {elapsed:.1f}s{R}")
    print(f"{CYAN}Saved to:{R} {SPECIAL_FILE}")
    print(f"{MAGENTA}═════════════════════════════════════════{R}\n")

    with open(LOG_FILE, 'w', encoding='utf-8') as f:
        f.write("\n".join(LOG_BUF))
    with open(SUMMARY_FILE, 'w', encoding='utf-8') as f:
        f.write(f"Naruto Spinner Summary\n")
        f.write(f"Accounts: {len(accounts)}\n")
        f.write(f"Hits: {hits}\n")
        f.write(f"Time: {elapsed:.1f}s\n")

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print(f"\n{RED}Stopped by user.{R}")
    except Exception as e:
        print(f"\n{RED}Fatal: {type(e).__name__}: {e}{R}")
        traceback.print_exc()